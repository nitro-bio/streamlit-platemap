declare module "smiles-drawer";
