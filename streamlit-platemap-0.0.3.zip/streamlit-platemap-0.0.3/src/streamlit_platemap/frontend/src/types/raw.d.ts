declare module "*.csv" {
  export = content as string;
}
